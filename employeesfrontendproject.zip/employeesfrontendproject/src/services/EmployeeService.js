import axios from "axios"

//import axios obj from axios library


 const REST_API_BASE_URL = 'http://localhost:8081/api/employee';
/* export const listEmployees=()=>
{
    return axios.get(REST_API_BASE_URL+'/get');
}

export const createEmployee=(employee)=>axios.post(REST_API_BASE_URL,employee +'/create');
 */


export const listEmployees = () => {
    return axios.get(`${REST_API_BASE_URL}/get`);
};

// Function to create a new employee
export const createEmployee = (employee) => {
    return axios.post(`${REST_API_BASE_URL}/create`, employee);
}; 
/* export const getEmployee=(employeeId)=>
{
    return axios.get(`${REST_API_BASE_URL}/get`, employeeId);
}; */

export const getEmployee = (employeeId) => {
    return axios.get(`${REST_API_BASE_URL}/get/${employeeId}`);
};
export const updateEmployee = (employeeId, employee) => 
    axios.put(`${REST_API_BASE_URL}/update/${employeeId}`, employee);

export const deleteEmployee = (employeeId) => 
    axios.delete(`${REST_API_BASE_URL}/delete/${employeeId}`);
