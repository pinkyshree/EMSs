import React, { useEffect, useState } from 'react';
import { createEmployee, getEmployee, updateEmployee } from '../services/EmployeeService';
import { useNavigate, useParams } from 'react-router-dom';
import { getAllDepartments } from '../services/DepartmentService';

const EmployeeComponent = () => {
    const [firstname, setfirstName] = useState('');
    const [lastname, setlastName] = useState('');
    const { id } = useParams();
    const [email, setEmail] = useState('');
    const [departmentId, setDepartmentId] = useState('');
    const [departments, setDepartments] = useState([]);
    const [errors, setErrors] = useState({
        firstname: '',
        lastname: '',
        email: '',
        department: '',
    });
    const navigate = useNavigate();

    useEffect(() => {
        getAllDepartments()
            .then((response) => setDepartments(response.data))
            .catch((error) => console.error(error));
    }, []);

    useEffect(() => {
        if (id) {
            getEmployee(id)
                .then((response) => {
                    setfirstName(response.data.firstname);
                    setlastName(response.data.lastname);
                    setEmail(response.data.email);
                    setDepartmentId(response.data.departmentId)
                })
                .catch((error) => console.error(error));
        }
    }, [id]);

    const handleLastName = (e) => setlastName(e.target.value);
    const handleEmail = (e) => setEmail(e.target.value);

    const pageTitle = () => {
        return id ? (
            <h2 className="text-center">Update Employee</h2>
        ) : (
            <h2 className="text-center">Add Employee</h2>
        );
    };

    function saveOrUpdateEmployee(e) {
        e.preventDefault();
        if (validateForm()) {
            const employee = { firstname, lastname, email, departmentId };
            if (id) {
                updateEmployee(id, employee)
                    .then((response) => {
                        console.log(response.data);
                        navigate('/employees');
                    })
                    .catch((error) => console.error(error));
            } else {
                createEmployee(employee)
                    .then((response) => {
                        console.log(response.data);
                        navigate('/employees');
                    })
                    .catch((error) => console.error(error));
            }
        }
    }

    function validateForm() {
        let valid = true;
        const errorsCopy = { ...errors };
        if (firstname.trim()) {
            errorsCopy.firstname = '';
        } else {
            errorsCopy.firstname = 'First name is required';
            valid = false;
        }
        if (lastname.trim()) {
            errorsCopy.lastname = '';
        } else {
            errorsCopy.lastname = 'Last name is required';
            valid = false;
        }
        if (email.trim()) {
            errorsCopy.email = '';
        } else {
            errorsCopy.email = 'Email is required';
            valid = false;
        }

        if (departmentId && departmentId !== "Select department") {
            errorsCopy.department = '';
        } else {
            errorsCopy.department = 'Department is required';
            valid = false;
        }
        setErrors(errorsCopy);
        return valid;
    }

    return (
        <div className="container">
            <br />
            <div className="row">
                <div className="card col-md-15 offset-md-9">
                    {pageTitle()}
                    <div className="card-body">
                        <form>
                            <div className="form-group mb-2">
                                <label className="form-label">First Name:</label>
                                <input
                                    type="text"
                                    placeholder="Enter employee first name"
                                    name="firstName"
                                    value={firstname}
                                    className={`form-control ${errors.firstname ? 'is-invalid' : ''}`}
                                    onChange={(e) => setfirstName(e.target.value)}
                                />
                                {errors.firstname && <div className="invalid-feedback">{errors.firstname}</div>}
                            </div>
                            <div className="form-group mb-2">
                                <label className="form-label">Last Name:</label>
                                <input
                                    type="text"
                                    placeholder="Enter employee last name"
                                    name="lastName"
                                    value={lastname}
                                    className={`form-control ${errors.lastname ? 'is-invalid' : ''}`}
                                    onChange={handleLastName}
                                />
                                {errors.lastname && <div className="invalid-feedback">{errors.lastname}</div>}
                            </div>
                            <div className="form-group mb-2">
                                <label className="form-label">Email:</label>
                                <input
                                    type="text"
                                    placeholder="Enter employee email"
                                    name="email"
                                    value={email}
                                    className={`form-control ${errors.email ? 'is-invalid' : ''}`}
                                    onChange={handleEmail}
                                />
                                {errors.email && <div className="invalid-feedback">{errors.email}</div>}
                            </div>
                            <div className="form-group mb-2">
                                <label className="form-label">Select Department:</label>
                                <select
                                    className={`form-control ${errors.department ? 'is-invalid' : ''}`}
                                    value={departmentId}
                                    onChange={(e) => setDepartmentId(e.target.value)}
                                >
                                    <option value="">Select department</option>
                                    {departments.map((department) => (
                                        <option key={department.id} value={department.id}>
                                            {department.departmentName}
                                        </option>
                                    ))}
                                </select>
                                {errors.department && <div className="invalid-feedback">{errors.department}</div>}
                            </div>
                            <button className="btn btn-success" onClick={saveOrUpdateEmployee}>
                                Submit
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default EmployeeComponent;
