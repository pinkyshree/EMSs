package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.dto.EmployeeDto;
import com.service.EmployeeService;
//all the clients can call employee related rest api
@RestController
@CrossOrigin("*")
@RequestMapping("/api/employee")
public class EmployeeController {
@Autowired
	private EmployeeService service;

@PostMapping("/create")
public ResponseEntity<EmployeeDto>  createemployee(@RequestBody EmployeeDto empdto)//will extract the json from http request and convert to java object
{
	EmployeeDto employeedto=service.createEmployee(empdto);
	return new ResponseEntity<> (employeedto,HttpStatus.CREATED);
}

@GetMapping("/get/{id}")
public ResponseEntity<EmployeeDto>  getemployeeid(@PathVariable("id") Long idd)//will extract the json from http request and convert to java object
{
	EmployeeDto employeedto=service.getEmployeeById(idd);
	return new ResponseEntity<EmployeeDto> (employeedto,HttpStatus.OK);
	
}



@GetMapping("/get")
public ResponseEntity<List<EmployeeDto>>  getallemployeelist()
{
	List<EmployeeDto> employeedto=service.getAllEmployees();
	return new ResponseEntity<List<EmployeeDto>> (employeedto,HttpStatus.OK);
	
	
}




@PutMapping("/update/{id}")
public ResponseEntity<EmployeeDto>  updateemployee(@PathVariable Long id, @RequestBody EmployeeDto empdto)//will extract the json from http request and convert to java object
{
	EmployeeDto employeedto=service.updateEmployee(id, empdto);
	return new ResponseEntity<> (employeedto,HttpStatus.OK);
}


@DeleteMapping("/delete/{id}")
public ResponseEntity<String> deleteemployee(@PathVariable Long id) {
    service.deleteEmployee(id);
    return ResponseEntity.ok("Employee deleted successfully with id: " + id);
}

}
