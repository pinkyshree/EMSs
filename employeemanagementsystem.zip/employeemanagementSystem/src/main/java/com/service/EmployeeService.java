package com.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dto.EmployeeDto;
import com.entity.Department;
import com.entity.EmployeeEntity;
import com.exception.ResourceNotFoundException;
import com.mapper.Employeemapper;
import com.repository.DepartmentRepository;
import com.repository.EmployeeRepository;

@Service
public class EmployeeService implements IEmployeeService {
@Autowired
	private EmployeeRepository repo;
@Autowired
private  DepartmentRepository departmenttrepo;
	@Override
	public EmployeeDto createEmployee(EmployeeDto employeedto) {
		
		EmployeeEntity employee=Employeemapper.maptoEmployeeEntity(employeedto);
		Department department=departmenttrepo.findById(employeedto.getDepartmentId()).orElseThrow(()-> new ResourceNotFoundException("department is not exists with id"
		+employeedto.getDepartmentId()));
		employee.setDepartment(department);
	EmployeeEntity savedemployee=	repo.save(employee);
		return Employeemapper.maptoEmployeeDto(savedemployee);
	}
	@Override
	public EmployeeDto getEmployeeById(Long id) {
		EmployeeEntity gemployee=repo.findById(id).orElseThrow(()->
		new ResourceNotFoundException("employee is not exists with id:"+id));
		return Employeemapper.maptoEmployeeDto(gemployee);
	}
	
	public List<EmployeeDto> getAllEmployees() {
		// TODO Auto-generated method stub
		List<EmployeeEntity> lemployees	=repo.findAll();
		return lemployees.stream().map((employee)->Employeemapper
				.maptoEmployeeDto(employee))
				.collect(Collectors.toList());}
	
	public EmployeeDto updateEmployee(Long employeeid, EmployeeDto updatedemployee) {
		EmployeeEntity employee=repo.findById(employeeid).orElseThrow(()->new
		 ResourceNotFoundException("employee is not exists with id:"+employeeid));
		employee.setFirstname(updatedemployee.getFirstname());
		employee.setLastname(updatedemployee.getLastname());
		employee.setEmail(updatedemployee.getEmail());
		Department department=departmenttrepo.findById(updatedemployee.getDepartmentId()).orElseThrow(()-> new ResourceNotFoundException("department is not exists with id"
				+updatedemployee.getDepartmentId()));
				employee.setDepartment(department);
EmployeeEntity uemployee=	repo.save(employee);
return Employeemapper.maptoEmployeeDto(uemployee);
	}
	
	
	@Override
	public void deleteEmployee(Long id) {
		EmployeeEntity gemployee=repo.findById(id).orElseThrow(()->
		new ResourceNotFoundException("employee is not exists with id:"+id));
		repo.deleteById(id);
		
	
	}

	
	
}
