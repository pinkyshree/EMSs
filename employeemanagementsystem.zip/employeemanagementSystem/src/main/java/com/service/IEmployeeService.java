package com.service;

import java.util.List;

import com.dto.EmployeeDto;

public interface IEmployeeService {

	EmployeeDto createEmployee(EmployeeDto employeedto);
	//EmployeeDto getEmployeeById(Long id);

	EmployeeDto getEmployeeById(Long id);
	List<EmployeeDto> getAllEmployees();
	
	EmployeeDto updateEmployee(Long employeeid,EmployeeDto updatedemployee);
	void deleteEmployee(Long id);
	
}
