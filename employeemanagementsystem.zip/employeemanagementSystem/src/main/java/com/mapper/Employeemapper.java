package com.mapper;

import com.dto.EmployeeDto;
import com.entity.EmployeeEntity;

public class Employeemapper {

	public static EmployeeDto maptoEmployeeDto(EmployeeEntity employee)
	{
	
		/*
		 * EmployeeDto employeedto= new EmployeeDto();
		 * employeedto.setId(employee.getId());
		 * employeedto.setFirstname(employee.getFirstname());
		 * employeedto.setLastname(employee.getLastname());
		 * employeedto.setEmail(employee.getEmail()); return employeedto;
		 */
		return new EmployeeDto(
				employee.getId(),
				employee.getFirstname(),	
				employee.getLastname(),	
				employee.getEmail(),
				employee.getDepartment().getId()
					
				);
	}
	
//	
	public static EmployeeEntity maptoEmployeeEntity(EmployeeDto empdto)
	{
	EmployeeEntity employee= new EmployeeEntity();
			employee.setId(empdto.getId());	
			employee.setFirstname(empdto.getFirstname());	
			employee.setLastname(empdto.getLastname());	
			employee.setEmail(empdto.getEmail());	
				return employee;
	}
}
